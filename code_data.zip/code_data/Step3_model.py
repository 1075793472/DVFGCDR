# python3
# -*- coding:utf-8 -*-

"""
@author:野山羊骑士
@e-mail：thankyoulaojiang@163.com
@file：PycharmProject-PyCharm-model.py
@time:2021/9/15 16:33 
"""
import scanpy as sc
import torch
from  process import *
from sklearn.neighbors import  kneighbors_graph
import os
import numpy as np
import pandas as pd
from torch_geometric.nn import GATConv
from sklearn.metrics import mean_squared_error
from lifelines.utils import concordance_index
from scipy.stats import pearsonr,spearmanr
import copy
import time
import pickle
from sklearn.decomposition import PCA
import torch
from torch.utils import data
import torch.nn.functional as F
from torch.autograd import Variable
from torch import nn
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import SequentialSampler
import hypergraph_utils  as hgut
from prettytable import PrettyTable
from torch_geometric.data import Data
from layers1 import *
from allset import SetGNN
from subword_nmt.apply_bpe import BPE
from model_helper import Encoder_MultipleLayers, Embeddings
from utils import load_data
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--train_prop', type=float, default=0.5)
parser.add_argument('--valid_prop', type=float, default=0.25)
parser.add_argument('--dname', default='walmart-trips-100')
# method in ['SetGNN','CEGCN','CEGAT','HyperGCN','HGNN','HCHA']
parser.add_argument('--method', default='AllSetTransformer')
parser.add_argument('--epochs', default=500, type=int)
# Number of runs for each split (test fix, only shuffle train/val)
parser.add_argument('--runs', default=20, type=int)
parser.add_argument('--cuda', default=0, choices=[-1, 0, 1], type=int)
parser.add_argument('--dropout', default=0.5, type=float)
parser.add_argument('--lr', default=0.001, type=float)
parser.add_argument('--wd', default=0.0, type=float)
# How many layers of full NLConvs
parser.add_argument('--All_num_layers', default=1, type=int)
parser.add_argument('--MLP_num_layers', default=2,
                    type=int)  # How many layers of encoder
parser.add_argument('--MLP_hidden', default=512,
                    type=int)  # Encoder hidden units
parser.add_argument('--Classifier_num_layers', default=1,
                    type=int)  # How many layers of decoder
parser.add_argument('--Classifier_hidden', default=256,
                    type=int)  # Decoder hidden units
parser.add_argument('--display_step', type=int, default=-1)
parser.add_argument('--aggregate', default='mean', choices=['sum', 'mean'])
parser.add_argument('--normtype', default='all_one')
parser.add_argument('--add_self_loop', action='store_false')
# NormLayer for MLP. ['bn','ln','None']
parser.add_argument('--normalization', default='ln')
parser.add_argument('--deepset_input_norm', default=True)
parser.add_argument('--GPR', action='store_false')  # skip all but last dec
# skip all but last dec
parser.add_argument('--LearnMask', action='store_false')
parser.add_argument('--num_features', default=512, type=int)  # Placeholder
parser.add_argument('--num_classes', default=256, type=int)  # Placeholder
# Choose std for synthetic feature noise
parser.add_argument('--feature_noise', default='1', type=str)
# whether the he contain self node or not
parser.add_argument('--exclude_self', action='store_true')
parser.add_argument('--PMA', action='store_true')
#     Args for HyperGCN
parser.add_argument('--HyperGCN_mediators', action='store_true')
parser.add_argument('--HyperGCN_fast', action='store_true')
#     Args for Attentions: GAT and SetGNN
parser.add_argument('--heads', default=4, type=int)  # Placeholder
parser.add_argument('--output_heads', default=1, type=int)  # Placeholder
#     Args for HNHN
parser.set_defaults(PMA=True)  # True: Use PMA. False: Use Deepsets.
parser.set_defaults(add_self_loop=True)
parser.set_defaults(exclude_self=False)
parser.set_defaults(GPR=False)
parser.set_defaults(LearnMask=False)
#     Use the line below for .py file
args = parser.parse_args()
def ExtractV2E(data):
    # Assume edge_index = [V|E;E|V]
    edge_index = data.edge_index
#     First, ensure the sorting is correct (increasing along edge_index[0])
    _, sorted_idx = torch.sort(edge_index[0])
    edge_index = edge_index[:, sorted_idx].type(torch.LongTensor)
    num_nodes = 1017
    cidx = torch.where(edge_index[0] == num_nodes)[
        0].min()  # cidx: [V...|cidx E...]
    data.edge_index = edge_index[:, :cidx].type(torch.LongTensor)
    return data.to(device)
def loadGR1(mm):

    dig=np.ones(mm.shape[0])
    I=np.diag(dig)
    H=mm.T
    # dr=dr
    G = hgut._generate_G_from_H(H)
    return G
def load_gcn(adj_):
    rowsum = np.array(adj_.sum(1))
    new_matrix = np.power(rowsum, -0.5)
    new_matrix[np.isnan(new_matrix) | np.isinf(new_matrix)] = 0.0
    degree_mat_inv_sqrt = np.diag(new_matrix.flatten())
    d=degree_mat_inv_sqrt.dot(adj_)
    adj_normalized=d.dot(degree_mat_inv_sqrt.T)
    #adj_normalized = adj_.dot(degree_mat_inv_sqrt).T.dot(degree_mat_inv_sqrt)
    return adj_normalized
def get_edge_index(matrix):
    edge_index = [[], []]
    value=[]
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if matrix[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
                value.append(matrix[i][j])
    edge=torch.LongTensor(edge_index).to(device)
    value1=torch.ones_like(edge[0]).to(device)
    return edge,value1
def build_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    neighbor2 = np.argsort(-sim, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
   # row_index,col_index=np.nonzero(sim)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
rnadata = pd.read_csv('Cell_line_RMA_proc_basalExp.txt', sep='\t')
rnadata = rnadata.drop(['GENE_SYMBOLS', 'GENE_title'], axis=1, inplace=False)
knn = np.array(rnadata.values.T)
K =10
#co_matrix,features=load_data(knn,'',512)
co_matrix = np.corrcoef(knn)
co_matrix = build_hypergraph(co_matrix, K)

co_matrix = torch.from_numpy(loadGR1(co_matrix)).to(device)
#co_matrix = torch.from_numpy(load_gcn(co_matrix)).to(device)
co_matrix=co_matrix.type(torch.float32)
knn1 = np.ceil(knn).astype(np.int)
adata = sc.AnnData(knn1)
adata = normalize(adata, copy=True, highly_genes=None, size_factors=True, normalize_input=True, logtrans_input=True)
count = adata.X
# var = np.var(knn, axis=0)
# min_var = np.sort(var)[-1 * 1024]
# features = knn.T[var >= min_var].T
# features = features[:, :1024]
pca = PCA(n_components=512)
features = pca.fit_transform(knn)
#adj=kneighbors_graph(features,10,mode='connectivity',metric='euclidean',include_self='False').toarray()
#adj,value=get_edge_index(adj)
adj,value=get_edge_index(co_matrix)
features = (features - np.mean(features)) / (np.std(features))
knn=torch.from_numpy(features).to(device).type(torch.float32)
#adj=ExtractV2E(adj)
#value=torch.ones_like(adj[0]).to(device)
data1=Data(edge_attr=value,edge_index=adj,x=knn)
#data1=ExtractV2E(data0)
#data1=Data(edge_attr=value,edge_index=adj,x=knn)
class data_process_loader(data.Dataset):
    def __init__(self, list_IDs, labels, drug_df,rna_df):
        'Initialization'
        self.labels = labels
        self.list_IDs = list_IDs
        self.drug_df = drug_df
        self.rna_df = rna_df

    def __len__(self):
        'Denotes the total number of samples'
        return len(self.list_IDs)

    def __getitem__(self, index):
        'Generates one sample of data'
        index = self.list_IDs[index]
        v_d = self.drug_df.iloc[index]['drug_encoding']
       # v_p = np.array(self.rna_df.iloc[index])
        v_p = np.array(self.rna_df[index])
        y = self.labels[index]
        return v_d, v_p, y

class transformer(nn.Sequential):
    def __init__(self):
        super(transformer, self).__init__()
        input_dim_drug = 2586
        transformer_emb_size_drug = 128
        transformer_dropout_rate = 0.1
        transformer_n_layer_drug = 8
        transformer_intermediate_size_drug = 512
        transformer_num_attention_heads_drug = 8
        transformer_attention_probs_dropout = 0.1
        transformer_hidden_dropout_rate = 0.1

        self.emb = Embeddings(input_dim_drug,
                         transformer_emb_size_drug,
                         50,
                         transformer_dropout_rate)

        self.encoder = Encoder_MultipleLayers(transformer_n_layer_drug,
                                         transformer_emb_size_drug,
                                         transformer_intermediate_size_drug,
                                         transformer_num_attention_heads_drug,
                                         transformer_attention_probs_dropout,
                                         transformer_hidden_dropout_rate)
    def forward(self, v):
        e = v[0].long().to(device)
        e_mask = v[1].long().to(device)
        ex_e_mask = e_mask.unsqueeze(1).unsqueeze(2)
        ex_e_mask = (1.0 - ex_e_mask) * -10000.0

        emb = self.emb(e)
        encoded_layers = self.encoder(emb.float(), ex_e_mask.float())
        return encoded_layers[:, 0]
from layers import HGNN_conv

class MLP_ALL(nn.Sequential):
    def __init__(self):
        input_dim_gene = 17737
        hidden_dim_gene = 256
        mlp_hidden_dims_gene = [1024,256,64]
        super(MLP_ALL, self).__init__()
        self.SetGNN = SetGNN(args)
    def forward(self, v1,data1,adj,co_matrix,rna):
        data1=F.relu(self.SetGNN(data1))
        v=data1[v1]
        return v
class MLP(nn.Sequential):
    def __init__(self):
        input_dim_gene = 17737
        hidden_dim_gene = 256
        mlp_hidden_dims_gene = [1024,256,64]
        super(MLP, self).__init__()
        layer_size = len(mlp_hidden_dims_gene) + 1
        dims = [input_dim_gene] + mlp_hidden_dims_gene + [hidden_dim_gene]
        self.predictor = nn.ModuleList([nn.Linear(dims[i], dims[i + 1]) for i in range(layer_size)])
        self.HGNN1 = HGNN_conv(1024,512, bias=True)
        self.HGNN2 = HGNN_conv(512,256, bias=True)
        # self.HGNN1 = HGNN_conv(1024, 512, bias=False)
        # self.HGNN2 = HGNN_conv(512, 256, bias=False)
        self.drop=nn.Dropout(0.3)
        self.drop1 = nn.Dropout(0.3)
    def forward(self, v1,adj,co_matrix,rna):
        v=rna[v1]
        #v = v.float().to(device)
        for i, l in enumerate(self.predictor):
            v = F.relu(l(v))
        return v
class MLP1(nn.Sequential):
    def __init__(self):
        input_dim_gene = 512
        hidden_dim_gene = 256
        mlp_hidden_dims_gene = [256]
        super(MLP1, self).__init__()
        layer_size = len(mlp_hidden_dims_gene) + 1
        dims = [input_dim_gene] + mlp_hidden_dims_gene + [hidden_dim_gene]
        self.predictor = nn.ModuleList([nn.Linear(dims[i], dims[i + 1]) for i in range(layer_size)])
        self.HGNN1 = HGNN_conv(512,256, bias=True)
        self.HGNN2 = HGNN_conv(256,256, bias=True)
        self.line=nn.Linear(512,256)
        self.drop=nn.Dropout(0.3)
        self.drop1 = nn.Dropout(0.3)
    def forward(self, v1,data1,adj,co_matrix,rna):
        rna= self.line(rna)
        rna = F.relu(rna)
        #rna=self.drop(rna)
        #rna=self.HGNN2(rna,co_matrix)
        #rna= F.relu(rna)
        # rna = self.drop1(rna)
        # rna=self.HGNN2(rna,co_matrix)
        # rna= F.relu(rna)
        v=rna[v1]
        # v = v.float().to(device)
        # for i, l in enumerate(self.predictor):
        #     v = F.relu(l(v))
        return v
class MLP2(nn.Sequential):
    def __init__(self):
        input_dim_gene = 512
        hidden_dim_gene = 256
        mlp_hidden_dims_gene = [256]
        super(MLP2, self).__init__()
        layer_size = len(mlp_hidden_dims_gene) + 1
        dims = [input_dim_gene] + mlp_hidden_dims_gene + [hidden_dim_gene]
        self.predictor = nn.ModuleList([nn.Linear(dims[i], dims[i + 1]) for i in range(layer_size)])
        self.HGNN1 = HGNN_conv(512,256, bias=True)
        self.HGNN2 = HGNN_conv(256,256, bias=True)
        self.drop=nn.Dropout(0.3)
        self.drop1 = nn.Dropout(0.3)
        self.head=4
        self.ppi_GAT1 = GATConv(512,256, heads=self.head, concat=False,dropout=0.3)
        self.ppi_GAT2 = GATConv(256, 256, heads=self.head, concat=False, dropout=0.3)
        self.bn1=nn.BatchNorm1d(256)
    def forward(self, v1,data1,adj,co_matrix,rna):
        rna= self.ppi_GAT1(rna,adj)
        rna1 = F.relu(rna)
        rna2= self.ppi_GAT2(rna1, adj)
        rna2= F.relu(rna2)
        rna=rna1+rna2
        v=rna[v1]
        return v

class Classifier(nn.Sequential):
    def __init__(self, model_drug, model_gene):
        super(Classifier, self).__init__()
        self.input_dim_drug = 128
        self.input_dim_gene = 256
        self.model_drug = model_drug
        self.model_gene = model_gene
        self.dropout = nn.Dropout(0.1)
        self.hidden_dims =  [1024, 1024, 512]
        layer_size = len(self.hidden_dims) + 1
        dims = [self.input_dim_drug + self.input_dim_gene] + self.hidden_dims + [1]
        self.predictor = nn.ModuleList([nn.Linear(dims[i], dims[i + 1]) for i in range(layer_size)])

    def forward(self, v_D, v_P,data1,adj,co_matrix,rna):
        # each encoding
        v_D = self.model_drug(v_D)
        v_P = self.model_gene(v_P,data1,adj,co_matrix,rna)
        # concatenate and classify
        v_f = torch.cat((v_D, v_P), 1)
        for i, l in enumerate(self.predictor):
            if i == (len(self.predictor) - 1):
                v_f = l(v_f)
            else:
                v_f = F.relu(self.dropout(l(v_f)))
        return v_f


class DeepTTC:
    def __init__(self,modeldir):
        model_drug = transformer()
        model_gene = MLP1()
        self.model = Classifier(model_drug,model_gene)
        self.device = torch.device('cuda:0')
        self.modeldir = modeldir
        self.record_file = os.path.join(self.modeldir, "valid_markdowntable.txt")
        self.pkl_file = os.path.join(self.modeldir, "loss_curve_iter.pkl")

    def test(self,datagenerator,model,rna):
        y_label = []
        y_pred = []
        model.eval()
        for i,(v_drug,v_gene,label) in enumerate(datagenerator):
            score = model(v_drug,v_gene,data1,adj,co_matrix,rna)
            loss_fct = torch.nn.MSELoss()
            n = torch.squeeze(score, 1)
            loss = loss_fct(n, Variable(torch.from_numpy(np.array(label)).float()).to(self.device))
            logits = torch.squeeze(score).detach().cpu().numpy()
            label_ids = label.to('cpu').numpy()
            y_label = y_label + label_ids.flatten().tolist()
            y_pred = y_pred + logits.flatten().tolist()

        model.train()

        return y_label, y_pred, \
               mean_squared_error(y_label, y_pred), \
               np.sqrt(mean_squared_error(y_label, y_pred)), \
               pearsonr(y_label, y_pred)[0], \
               pearsonr(y_label, y_pred)[1], \
               spearmanr(y_label, y_pred)[0], \
               spearmanr(y_label, y_pred)[1], \
               concordance_index(y_label, y_pred), \
               loss

    def train(self, train_drug, train_rna, val_drug, val_rna,rna):
        lr = 1e-4
        decay = 0
        BATCH_SIZE = 128
        train_epoch = 300
        self.model = self.model.to(self.device)
        # self.model = torch.nn.DataParallel(self.model, device_ids=[0, 5])
        opt = torch.optim.Adam(self.model.parameters(), lr=lr, weight_decay=decay)
        loss_history = []

        params = {'batch_size': BATCH_SIZE,
                  'shuffle': True,
                  'num_workers': 0,
                  'drop_last': False}
        training_generator = data.DataLoader(data_process_loader(
            train_drug.index.values, train_drug.Label.values, train_drug, train_rna), **params)
        validation_generator = data.DataLoader(data_process_loader(
            val_drug.index.values, val_drug.Label.values, val_drug, val_rna), **params)

        max_MSE = 10000
        model_max = copy.deepcopy(self.model)

        valid_metric_record = []
        valid_metric_header = ['# epoch',"MSE", 'RMSE',
                                    "Pearson Correlation", "with p-value",
                                    'Spearman Correlation',"with p-value2",
                                    "Concordance Index"]
        table = PrettyTable(valid_metric_header)
        float2str = lambda x: '%0.4f' % x
        print('--- Go for Training ---')
        writer = SummaryWriter(self.modeldir, comment='Drug_Transformer_MLP')
        t_start = time.time()
        iteration_loss = 0

        for epo in range(train_epoch):
            for i, (v_d, v_p, label) in enumerate(training_generator):
                # print(v_d,v_p)
                # v_d = v_d.float().to(self.device)
                score = self.model(v_d, v_p,data1,adj,co_matrix,rna)
                label = Variable(torch.from_numpy(np.array(label))).float().to(self.device)

                loss_fct = torch.nn.MSELoss()
                n = torch.squeeze(score, 1).float()
                loss = loss_fct(n, label)
                loss_history.append(loss.item())
                writer.add_scalar("Loss/train", loss.item(), iteration_loss)
                iteration_loss += 1

                opt.zero_grad()
                loss.backward()
                opt.step()
                if (i % 1000 == 0):
                    t_now = time.time()
                    print('Training at Epoch ' + str(epo + 1) +
                          ' iteration ' + str(i) + \
                          ' with loss ' + str(loss.cpu().detach().numpy())[:7] + \
                          ". Total time " + str(int(t_now - t_start) / 3600)[:7] + " hours")

            with torch.set_grad_enabled(False):
                ### regression: MSE, Pearson Correlation, with p-value, Concordance Index
                y_true,y_pred, mse, rmse, \
                person, p_val, \
                spearman, s_p_val, CI,\
                loss_val = self.test(validation_generator, self.model,rna)
                lst = ["epoch " + str(epo)] + list(map(float2str, [mse, rmse, person, p_val, spearman,
                                                                   s_p_val, CI]))
                valid_metric_record.append(lst)
                if mse < max_MSE:
                    model_max = copy.deepcopy(self.model)
                    max_MSE = mse
                    print('Validation at Epoch ' + str(epo + 1) +
                          ' with loss:' + str(loss_val.item())[:7] +
                          ', MSE: ' + str(mse)[:7] +
                          ' , Pearson Correlation: ' + str(person)[:7] +
                          ' with p-value: ' + str(p_val)[:7] +
                          ' Spearman Correlation: ' + str(spearman)[:7] +
                          ' with p_value: ' + str(s_p_val)[:7] +
                          ' , Concordance Index: ' + str(CI)[:7])
                    writer.add_scalar("valid/mse", mse, epo)
                    writer.add_scalar('valida/rmse', rmse, epo)
                    writer.add_scalar("valid/pearson_correlation", person, epo)
                    writer.add_scalar("valid/concordance_index", CI, epo)
                    writer.add_scalar("valid/Spearman", spearman, epo)
                    writer.add_scalar("Loss/valid", loss_val.item(), iteration_loss)
            table.add_row(lst)

        self.model = model_max

        with open(self.record_file, 'w') as fp:
            fp.write(table.get_string())
        with open(self.pkl_file, 'wb') as pck:
            pickle.dump(loss_history, pck)

        print('--- Training Finished ---')
        writer.flush()
        writer.close()

    def predict(self, drug_data, rna_data):
        print('predicting...')
        self.model.to(device)
        info = data_process_loader(drug_data.index.values,
                                   drug_data.Label.values,
                                   drug_data, rna_data)
        params = {'batch_size': 16,
                  'shuffle': False,
                  'num_workers': 0,
                  'drop_last': False,
                  'sampler': SequentialSampler(info)}
        generator = data.DataLoader(info, **params)

        y_label, y_pred, mse, rmse, person, p_val, spearman, s_p_val, CI, loss_val = \
            self.test(generator, self.model)

        return y_label, y_pred, mse, rmse, person, p_val, spearman, s_p_val, CI

    def save_model(self):
        torch.save(self.model.state_dict(), self.modeldir + '/model.pt')

    def load_pretrained(self, path):
        if not os.path.exists(path):
            os.makedirs(path)

        if self.device == 'cuda':
            state_dict = torch.load(path)
        else:
            state_dict = torch.load(path, map_location=torch.device('cpu'))

        if next(iter(state_dict))[:7] == 'module.':
            # the pretrained model is from data-parallel module
            from collections import OrderedDict
            new_state_dict = OrderedDict()
            for k, v in state_dict.items():
                name = k[7:]  # remove `module.`
                new_state_dict[name] = v
            state_dict = new_state_dict

        self.model.load_state_dict(state_dict)


if __name__ == '__main__':

    # step1 数据切分
    from Step2_DataEncoding import DataEncoding
    vocab_dir = '/home/s3540/DTI/DeepTTC-main'
    obj = DataEncoding(vocab_dir=vocab_dir)

    # 切分完成
    traindata, testdata = obj.Getdata.ByCancer(random_seed=1)
    # encoding 完成
    traindata, train_rnadata, testdata, test_rnadata = obj.encode(
        traindata=traindata,
        testdata=testdata)

    # step2：构造模型
    modeldir = '/home/s3540/DTI/DeepTTC-main/Model_80'
    modelfile = modeldir + '/model.pt'
    if not os.path.exists(modeldir):
        os.mkdir(modeldir)

    net = DeepTTC(modeldir=modeldir)
    net.train(train_drug=traindata, train_rna=train_rnadata,
              val_drug=testdata, val_rna=test_rnadata,rna=knn)
    net.save_model()
    print("Model Saveed :{}".format(modelfile))



