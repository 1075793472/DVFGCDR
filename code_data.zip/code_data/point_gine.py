import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Sequential, Linear, ReLU,BatchNorm1d,LeakyReLU,Tanh,Embedding
from torch_geometric.nn import GINConv, global_add_pool,BatchNorm,EdgeConv
from torch_geometric.nn import global_mean_pool as gap, global_max_pool as gmp
from rgat_conv import RGATConv
from point_transformer_conv import PointTransformerConv
from torch_geometric.nn import GCNConv,GATConv,PointConv,DynamicEdgeConv
from DGCNN import EdgeConv
from  gin import GINEConv
from torch_geometric.nn import GCNConv,radius_graph
# from torch_geometric.nn import GCNConv
torch.manual_seed(1)
torch.cuda.manual_seed(1)
torch.cuda.manual_seed_all(1)
class my_Attention(nn.Module):
    def __init__(self, in_size=256, hidden_size=64):
        super(my_Attention, self).__init__()
        self.avg_pool=nn.AdaptiveAvgPool1d(1)
        self.project = nn.Sequential(
            nn.Linear(in_size, hidden_size),
            nn.ReLU(),
            #nn.Tanh(),
            nn.Linear(hidden_size, 1,bias=False)
            #nn.Sigmoid()
        )

    def forward(self, z):

        w = self.project(z)

        beta = torch.softmax(w, dim=1)

        return (beta * z).sum(1), beta
class SEAttention(nn.Module):

    def __init__(self, channel=512,reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, reduction),
            #nn.ReLU(),
            #nn.LeakyReLU(),
            nn.Tanh(),
            nn.Linear(reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)
class LayerNorm(nn.Module):
    """Construct a layernorm module (See citation for details)."""

    def __init__(self, features, eps=1e-6):
        super(LayerNorm, self).__init__()
        self.a_2 = nn.Parameter(torch.ones(features))
        self.b_2 = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a_2 * (x - mean) / (std + self.eps) + self.b_2
class GINConvNet(torch.nn.Module):
    def __init__(self, n_output=1,num_features_xd=40, num_features_xt=25,
                 n_filters=32, embed_dim=128, output_dim=128, dropout=0.2):

        super(GINConvNet, self).__init__()

        dim =256
        hid_dim_gin=256-64
        out_dim=dim
        point_dim = dim
        em_dim=32
       # self.emb=Embedding(100,32)
        self.emb1 = Embedding(15+1, em_dim)
        self.emb2 = Embedding(5 + 1, em_dim)
        self.emb3 = Embedding(5 + 1, em_dim)
        self.emb4 = Embedding(5 + 1, em_dim)
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        self.n_output = n_output
        self.embed_dim=7
        e_dim = 32
        self.act1 = nn.ReLU()
        self.act2 = nn.ReLU()
        self.bn_gin1=BatchNorm1d(hid_dim_gin)
        self.bn_gin2 = BatchNorm1d(hid_dim_gin)
        self.bn_gin3 = BatchNorm1d(hid_dim_gin)
        self.bn_gin4 = BatchNorm1d(out_dim)
        self.bn_gin5 = BatchNorm1d(out_dim)
        nn1 = Sequential(Linear(e_dim * 3 + 1, e_dim * 3 + 1), self.act1, Linear(e_dim * 3 + 1, hid_dim_gin))
        self.conv1 = GINEConv(nn1, edge_dim=self.embed_dim, train_eps=True)
        nn2 = Sequential(Linear(out_dim, out_dim), self.act1, Linear(out_dim, hid_dim_gin))
        self.conv2 = GINEConv(nn2, edge_dim=self.embed_dim, train_eps=True)
        nn3 = Sequential(Linear(out_dim, out_dim), self.act1, Linear(out_dim, hid_dim_gin))
        self.conv3 = GINEConv(nn3, edge_dim=self.embed_dim, train_eps=True)
        nn4 = Sequential(Linear(out_dim, out_dim), self.act1, Linear(out_dim, out_dim))
        self.conv4 = GINEConv(nn4, edge_dim=self.embed_dim, train_eps=True)
        #self.conv5 = GINConv(nn5)
        self.bn6 = BatchNorm1d(output_dim)
        self.bn8 =BatchNorm1d(output_dim)
        self.bn10 = torch.nn.BatchNorm1d(256)
        self.bn128 = torch.nn.BatchNorm1d(128)
        self.last2 = Sequential(Linear(2 * dim, output_dim ),ReLU())
        self.final = nn.Linear(output_dim,output_dim)
        egconv1 = Sequential(Linear(2 * 3, 64), ReLU(), Linear(64, 64))
        egconv2 = Sequential(Linear(2 * 64, point_dim), ReLU(), Linear(point_dim, point_dim))
        egconv3 = Sequential(Linear(2 * point_dim, point_dim), ReLU(), Linear(point_dim, point_dim))
        egconv4 = Sequential(Linear(2 * point_dim, point_dim), ReLU(), Linear(point_dim, point_dim))
        self.EdgeConv1=EdgeConv(egconv1,aggr='max')
        self.EdgeConv2 = EdgeConv(egconv2,aggr='max')
        self.EdgeConv3 = EdgeConv(egconv3,aggr='max')
        self.EdgeConv4 = EdgeConv(egconv4, aggr='max')
        self.last3 = Sequential(Linear(dim+point_dim, output_dim), ReLU())
        self.bn1 = BatchNorm1d(64)
        self.bn2 = BatchNorm1d(out_dim)
        self.bn3 = BatchNorm1d(point_dim)
        self.bn4 = BatchNorm1d(point_dim)
        self.line1 =nn.Linear(self.embed_dim,32)
        self.line2 = nn.Linear(32,32)
        self.line3 = nn.Linear(32,32)
        self.line4 = nn.Linear(32,32)
        self.drop=nn.Dropout(0.1)
        self.att=nn.Parameter(torch.ones(2,1,1)/2)
        self.se=my_Attention()
    def forward(self, data,data1,func):

        x, edge_index,edge_type, batch = data.x, data.edge_index,data.edge_attr, data.batch
        pos, edge_index_e, type_e, batch_e = data1.x, data1.edge_index, data1.edge_attr, data1.batch
        x = x[:, :-3]
        x_f1=self.emb1(torch.squeeze(x[:,0]))
        x_f2=self.emb2(x[:,1])+self.emb3(x[:,2])+self.emb4(x[:,3])
        x_f3=x[:,4]-1
       # print(x_f3)
        edge_type = edge_type[:, :self.embed_dim]
        x=torch.cat((x_f1,x_f2,x_f3.unsqueeze(1)),1)
        x1 = self.bn_gin1(F.relu(self.conv1(x, edge_index,edge_type)))
        x2 =self.bn_gin2(F.relu(self.conv2(x1, edge_index,edge_type)))
        x3 = self.bn_gin3(F.relu(self.conv3(x2, edge_index,edge_type)))
        #x4 = F.relu(self.conv4(x3, edge_index))
        x4 = self.bn_gin4(F.relu(self.conv4(x3, edge_index,edge_type)))
        # x5 = self.bn_gin5(F.relu(self.conv4(x4, edge_index,edge_type)))

        x_e1 = self.bn1(F.relu(self.EdgeConv1(pos, edge_index_e)))
        x_e2 = self.bn2(F.relu(self.EdgeConv2(x_e1, edge_index_e)))
        x_e3 = self.bn3(F.relu(self.EdgeConv3(x_e2, edge_index_e)))
        x_e4 = self.bn4(F.relu(self.EdgeConv4(x_e3, edge_index_e)))
        # x_e = torch.cat((x_e3.unsqueeze(0), x4.unsqueeze(0)),0)
        # x_e=x_e.transpose(0,1)
        x_e = torch.stack([x_e4, x4], 1)
        #emb = torch.stack([emb1, emb2, Xcom], dim=1)
        #x_e = x_e.transpose(0, 1)
        #print(xr.shape)
        x_e, att = self.se(x_e)
        # x_e=x_e.unsqueeze(0)
        # #x_e = x_e.view(1, 2, 256, -1)
        # x_e = torch.transpose(x_e,2,3)
        # # att=torch.softmax(self.att,dim=0)
        # # print(att)
        # #x_e=torch.sum(x_e*att,dim=0)
        # #print(x_e.shape)
        # x_e,_= self.se(x_e)
        # x_e = x_e.squeeze()
        # x_e = x_e.sum(dim=0).T
        #x_e3 =F.relu(self.EdgeConv3(x_e2, edge_index_e))
        #x_e=self.bn8(F.relu(x_e+x4))
        #x_e=torch.cat((x_e3,x4),1)
        #x_e = 0.9*x_e3+0.1*x4
        #x_e = self.bn8(x_e)
       # x_e = F.relu(self.final(x_e))
        #x_e =self.bn10(F.relu((x_e3+x4)))

        # max1 = self.bn6(global_add_pool(x_e3, batch_e))
        # max2 = self.bn10(global_add_pool(x4, batch))

        max1=global_add_pool(x_e, batch)
        max1 = self.bn6(max1)
        #max1=torch.cat((max1,max2),1)
        #max1 =max1)
        #max1 = max1)
        #max1=max1+max2
       # max1 = self.bn8(F.relu(self.final(max1)))
        #max1 = self.bn10(F.relu(self.final(max1)))

        return max1
